<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CouponController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ProductsOfTheMonthController;
use App\Http\Controllers\UserController;


Route::get('/', function () {
    return view('home');
});

Route::get('/home', function () {
    return view('home');
});

Route::resource('/categories', CategoryController::class);
Route::resource('/products', ProductController::class);
Route::resource('/coupons', CouponController::class);
Route::resource('/customers', CustomerController::class);
Route::resource('/products-of-the-month', ProductsOfTheMonthController::class);
Route::resource('/users', UserController::class);
