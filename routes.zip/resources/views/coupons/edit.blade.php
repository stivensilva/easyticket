@extends('layout')

@section('content')

  <div>
    <a href="{{ url('coupons') }}" class="btn btn-secondary float-end"><i class="bx bx-undo"></i>Back</a>
    <h4 class="fw-bold py-3 mb-4">Edit coupon</h4>
  </div>

  <div class="row">
    <div class="col-xl">
      <div class="card mb-4">
        <div class="card-body">
        <form action="{{ url('coupons/'.$data->id) }}" method="POST">
            @csrf
            @method('put')
            <div class="row">

              <div class="mb-3 col-md-6">
                <label class="form-label" for="basic-icon-default-fullname">Product</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-fullname2" class="input-group-text">
                    <i class="bx bx-purchase-tag"></i>
                  </span>
                  <select name="product_id" class="form-control" required autofocus>
                    <option value="">Select product...</option>
                    @foreach($products as $product)
                      @if(old('nombre', $data->id) == $product->id)
                        <option value="{{$product->id}}" selected> {{$product->name}} </option>
                      @else
                        <option value="{{$product->id}}"> {{$product->name}} </option>
                      @endif
                    @endforeach
                  </select>
                </div>
                @error('product_id')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>

              <div class="mb-3 col-md-6">
                <label class="form-label" for="basic-icon-default-fullname">Percentage</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-fullname2" class="input-group-text">
                    <i class="bx bxs-discount"></i>
                  </span>
                  <input
                    type="number"
                    name="percentage"
                    class="form-control"
                    min="0"
                    required
                    value="{{ old('percentage', $data->percentage) }}"
                  />
                </div>
                @error('percentage')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>
              
              <div class="mb-3 col-md-6">
                <label class="form-label" for="basic-icon-default-company">Start date</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-company2" class="input-group-text">
                    <i class="bx bx-calendar"></i>
                  </span>
                  <input
                    type="date"
                    name="startdate"
                    class="form-control"
                    required
                    value="{{ old('startdate', $data->startdate) }}"
                  />
                </div>
                @error('startdate')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>

              <div class="mb-3 col-md-6">
                <label class="form-label" for="basic-icon-default-company">End date</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-company2" class="input-group-text">
                    <i class="bx bx-calendar"></i>
                  </span>
                  <input
                    type="date"
                    name="enddate"
                    class="form-control"
                    required
                    value="{{ old('enddate', $data->enddate) }}"
                  />
                </div>
                @error('enddate')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>

              <div class="mb-3 col-md-6">
                <label class="form-label" for="basic-icon-default-fullname">Status</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-fullname2" class="input-group-text">
                    <i class="bx bx-check-circle"></i>
                  </span>
                  <select name="status" class="form-control" required>
                    @if(old('status', $data->status))
                      <option value="1" selected>Active</option>
                      <option value="0">Inactive</option>
                    @else
                      <option value="1">Active</option>
                      <option value="0" selected>Inactive</option>
                    @endif
                    </select>
                </div>
                @error('status')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>
              
              <button type="submit" class="btn btn-primary">Send</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  
@stop