@extends('layout')

@section('content')

  <div>
    <a href="{{ url('products/create') }}" class="btn btn-primary float-end"><i class="bx bx-plus"></i>New</a>
    <h4 class="fw-bold py-3 mb-4">Products</h4>
  </div>

  <div class="card p-3">
    <!-- <h5 class="card-header">Table Basic</h5> -->
    <div class="table-responsive text-nowrap">
      <table class="table table-hover ">
        <thead>
          <tr>
            <th>Image</th>
            <th>Name</th>
            <!-- <th>Description</th> -->
            <th>Category</th>
            <th>Price</th>
            <th>Bestseller ?</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody class="table-border-bottom-0">
        @foreach($data as $product)
          <tr>
            <!-- <td>{{ $product->description }}</td> -->
            <td>
              <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                <li
                data-bs-toggle="tooltip"
                data-popup="tooltip-custom"
                data-bs-placement="top"
                class="avatar avatar-xs pull-up"
                title="{{ $product->name }}"
                >
                  <a href="{{ url('images/products/'.$product->image) }}" data-lightbox="{{ $product->name }}" data-title="{{ $product->name }}">
                    <img src="{{ url('images/products/'.$product->image) }}" alt="Avatar" class="rounded" />
                  </a>
                </li>
              </ul>
            </td>
            <td><strong>{{ $product->name }}</strong></td>
            <td>{{ $product->category->name }}</td>
            <td>$ {{ $product->price }}</td>
            <td>
              @if($product->bestseller)
                <span class="badge bg-label-success me-1">YES</span>
              @else
                <span class="badge bg-label-danger me-1">NO</span>
              @endif     
            </td>
            <td>
              @if($product->status)
                <span class="badge bg-label-success me-1">Active</span>
              @else
                <span class="badge bg-label-danger me-1">Inactive</span>
              @endif 
            </td>
            <td>
              <a href="#" class="btn btn-outline-dark btn-sm" title="Detail product">
                <i class="bx bx-search"></i>
              </a>
              <a href="{{ url('products/'.$product->id.'/edit') }}" class="btn btn-outline-dark btn-sm" title="Edit product">
                <i class="bx bx-pencil"></i>
              </a>
              <form action="{{ url('products/'.$product->id) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                @if($product->status)
                  <button type="submit" class="btn btn-outline-dark btn-sm" title="Inactivate product" onclick="return confirm('Are you sure you want to inactivate this product?')">
                    <i class="bx bx-trash"></i>
                  </button>
                @else
                  <button type="submit" class="btn btn-outline-dark btn-sm" title="Activate product" onclick="return confirm('Are you sure you want to activate this product?')">
                    <i class="bx bx-recycle"></i>
                  </button>
                @endif
            </td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>
  </div>

@stop