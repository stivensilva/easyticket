@extends('layout')

@section('content')

  <div>
    <a href="{{ url('users/create') }}" class="btn btn-primary float-end"><i class="bx bx-plus"></i>New</a>
    <h4 class="fw-bold py-3 mb-4">Users</h4>
  </div>

  <div class="card p-3">
    <!-- <h5 class="card-header">Table Basic</h5> -->
    <div class="table-responsive text-nowrap">
      <table class="table table-hover ">
        <thead>
          <tr>
            <th>Name</th>
            <th>E-mail</th>
            <th>Role</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody class="table-border-bottom-0">
        @foreach($data as $user)
          <tr>
            <td><strong>{{ $user->name }}</strong></td>
            <td>{{ $user->email }}</td>
            <td>{{ $user->role }}</td>
            <td>
              @if($user->status)
                <span class="badge bg-label-success me-1">Active</span>
              @else
                <span class="badge bg-label-danger me-1">Inactive</span>
              @endif 
            </td>
            <td>
              <a href="#" class="btn btn-outline-dark btn-sm" title="Detail user">
                <i class="bx bx-search"></i>
              </a>
              <a href="{{ url('users/'.$user->id.'/edit') }}" class="btn btn-outline-dark btn-sm" title="Edit user">
                <i class="bx bx-pencil"></i>
              </a>
              <form action="{{ url('users/'.$user->id) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                @if($user->status)
                  <button type="submit" class="btn btn-outline-dark btn-sm" title="Inactivate user" onclick="return confirm('Are you sure you want to inactivate this user?')">
                    <i class="bx bx-trash"></i>
                  </button>
                @else
                  <button type="submit" class="btn btn-outline-dark btn-sm" title="Activate user" onclick="return confirm('Are you sure you want to activate this user?')">
                    <i class="bx bx-recycle"></i>
                  </button>
                @endif
            </td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>
  </div>

@stop