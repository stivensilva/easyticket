@extends('layout')

@section('content')

  <div>
    <a href="{{ url('coupons') }}" class="btn btn-secondary float-end"><i class="bx bx-undo"></i>Back</a>
    <h4 class="fw-bold py-3 mb-4">New customer</h4>
  </div>

  <div class="row">
    <div class="col-xl">
      <div class="card mb-4">
        <div class="card-body">
          <form action="{{ url('customers') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row">

              <div class="mb-3 col-md-6">
                <label class="form-label" for="basic-icon-default-fullname">Name</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-fullname2" class="input-group-text">
                    <i class="bx bxs-discount"></i>
                  </span>
                  <input
                    type="text"
                    name="name"
                    class="form-control"
                    required
                    autofocus
                    value="{{ old('name') }}"
                  />
                </div>
                @error('name')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>
              
              <div class="mb-3 col-md-6">
                <label class="form-label" for="basic-icon-default-company">E-mail</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-company2" class="input-group-text">
                    <i class="bx bx-envelope"></i>
                  </span>
                  <input
                    type="email"
                    name="email"
                    class="form-control"
                    required
                    value="{{ old('email') }}"
                  />
                </div>
                @error('email')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>

              <div class="mb-3 col-md-6">
                <label class="form-label" for="basic-icon-default-company">Phone</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-company2" class="input-group-text">
                    <i class="bx bx-phone"></i>
                  </span>
                  <input
                    type="number"
                    name="phone"
                    class="form-control"
                    required
                    value="{{ old('phone') }}"
                  />
                </div>
                @error('phone')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>

              <div class="mb-3 col-md-3">
                <label class="form-label" for="basic-icon-default-company">Birth day</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-company2" class="input-group-text">
                    <i class="bx bx-calendar"></i>
                  </span>
                  <select name="birthday" class="form-control" required>
                    @for ($i = 1; $i <= 31; $i++) {
                      <option value='{{ $i }}'>{{ $i }}</option>";
                    @endfor
                  </select>
                </div>
                @error('birthday')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>

              <div class="mb-3 col-md-3">
                <label class="form-label" for="basic-icon-default-company">Birth month</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-company2" class="input-group-text">
                    <i class="bx bx-calendar"></i>
                  </span>
                  <select name="birthmonth" class="form-control" required>
                    <option value="1">January</option>
                    <option value="2">February</option>
                    <option value="3">March</option>
                    <option value="4">April</option>
                    <option value="5">May</option>
                    <option value="6">June</option>
                    <option value="7">July</option>
                    <option value="8">August</option>
                    <option value="9">September</option>
                    <option value="10">October</option>
                    <option value="11">November</option>
                    <option value="12">December</option>
                  </select>
                </div>
                @error('birthmonth')
                  <small class="invalid-feedback"> {{ $message }} </small>
                @enderror
              </div>

              <button type="submit" class="btn btn-primary">Send</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  
@stop