<?php $__env->startSection('content'); ?>

  <div>
    <a href="<?php echo e(url('categories')); ?>" class="btn btn-secondary float-end"><i class="bx bx-undo"></i>Back</a>
    <h4 class="fw-bold py-3 mb-4">Edit category</h4>
  </div>

  <div class="row">
    <div class="col-xl">
      <div class="card mb-4">
        <div class="card-body">
          <form action="<?php echo e(url('categories/'.$data->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="row">
              <div class="mb-3 col-md-5">
                <label class="form-label" for="basic-icon-default-fullname">Full Name</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-fullname2" class="input-group-text">
                    <i class="bx bx-user"></i>
                  </span>
                  <input
                    type="text"
                    name="name"
                    class="form-control"
                    autofocus
                    value="<?php echo e($data->name); ?>"
                  />
                </div>
              </div>

              <div class="mb-3 col-md-2" style="text-align:right">
                <img src="<?php echo e(url('images/categories/'.$data->image)); ?>" alt="" style="height: 80px; width:80px; border: 1px solid #d9dee3; padding: 2px; border-radius: 10px;">
              </div>

              <div class="mb-3 col-md-5">
                <label class="form-label" for="basic-icon-default-company">Image</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-company2" class="input-group-text">
                    <i class="bx bx-image-add"></i>
                  </span>
                  <input
                    type="file"
                    name="image"
                    class="form-control"
                    accept="image/*"
                  />
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label" for="basic-icon-default-message">Description</label>
                <div class="input-group input-group-merge">
                  <span id="basic-icon-default-message2" class="input-group-text">
                    <i class="bx bx-comment"></i>
                  </span>
                  <textarea
                    class="form-control"
                    name="description"
                    rows="5"
                  ><?php echo e($data->description); ?>

                  </textarea>
                </div>
              </div>
              <button type="submit" class="btn btn-primary">Send</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\supermarket-admin\resources\views/categories/edit.blade.php ENDPATH**/ ?>