<?php $__env->startSection('content'); ?>

  <div>
    <a href="<?php echo e(url('coupons/create')); ?>" class="btn btn-primary float-end"><i class="bx bx-plus"></i>New</a>
    <h4 class="fw-bold py-3 mb-4">Coupons</h4>
  </div>

  <div class="card p-3">
    <!-- <h5 class="card-header">Table Basic</h5> -->
    <div class="table-responsive text-nowrap">
      <table class="table table-hover ">
        <thead>
          <tr>
            <th>Product</th>
            <th>Percentage</th>
            <th>Start date</th>
            <th>End date</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody class="table-border-bottom-0">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><strong><?php echo e($coupon->product->name); ?></strong></td>
            <td><?php echo e($coupon->percentage); ?> %</td>
            <td><?php echo e($coupon->startdate); ?></td>
            <td><?php echo e($coupon->enddate); ?></td>
            <td>
              <?php if($coupon->status): ?>
                <span class="badge bg-label-success me-1">Active</span>
              <?php else: ?>
                <span class="badge bg-label-danger me-1">Inactive</span>
              <?php endif; ?> 
            </td>
            <td>
              <a href="#" class="btn btn-outline-dark btn-sm" title="Detail coupon">
                <i class="bx bx-search"></i>
              </a>
              <a href="<?php echo e(url('coupons/'.$coupon->id.'/edit')); ?>" class="btn btn-outline-dark btn-sm" title="Edit coupon">
                <i class="bx bx-pencil"></i>
              </a>
              <form action="<?php echo e(url('coupons/'.$coupon->id)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <?php if($coupon->status): ?>
                  <button type="submit" class="btn btn-outline-dark btn-sm" title="Inactivate coupon" onclick="return confirm('Are you sure you want to inactivate this coupon?')">
                    <i class="bx bx-trash"></i>
                  </button>
                <?php else: ?>
                  <button type="submit" class="btn btn-outline-dark btn-sm" title="Activate coupon" onclick="return confirm('Are you sure you want to activate this coupon?')">
                    <i class="bx bx-recycle"></i>
                  </button>
                <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp3\htdocs\supermarket-admin\resources\views/coupons/index.blade.php ENDPATH**/ ?>