<?php $__env->startSection('content'); ?>

  <div>
    <a href="<?php echo e(url('products/create')); ?>" class="btn btn-primary float-end"><i class="bx bx-plus"></i>New</a>
    <h4 class="fw-bold py-3 mb-4">Products</h4>
  </div>

  <div class="card p-3">
    <!-- <h5 class="card-header">Table Basic</h5> -->
    <div class="table-responsive text-nowrap">
      <table class="table table-hover ">
        <thead>
          <tr>
            <th>Image</th>
            <th>Name</th>
            <!-- <th>Description</th> -->
            <th>Category</th>
            <th>Price</th>
            <th>Bestseller ?</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody class="table-border-bottom-0">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <!-- <td><?php echo e($product->description); ?></td> -->
            <td>
              <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                <li
                data-bs-toggle="tooltip"
                data-popup="tooltip-custom"
                data-bs-placement="top"
                class="avatar avatar-xs pull-up"
                title="<?php echo e($product->name); ?>"
                >
                  <a href="<?php echo e(url('images/products/'.$product->image)); ?>" data-lightbox="<?php echo e($product->name); ?>" data-title="<?php echo e($product->name); ?>">
                    <img src="<?php echo e(url('images/products/'.$product->image)); ?>" alt="Avatar" class="rounded" />
                  </a>
                </li>
              </ul>
            </td>
            <td><strong><?php echo e($product->name); ?></strong></td>
            <td><?php echo e($product->category->name); ?></td>
            <td>$ <?php echo e($product->price); ?></td>
            <td>
              <?php if($product->bestseller): ?>
                <span class="badge bg-label-success me-1">YES</span>
              <?php else: ?>
                <span class="badge bg-label-danger me-1">NO</span>
              <?php endif; ?>     
            </td>
            <td>
              <?php if($product->status): ?>
                <span class="badge bg-label-success me-1">Active</span>
              <?php else: ?>
                <span class="badge bg-label-danger me-1">Inactive</span>
              <?php endif; ?> 
            </td>
            <td>
              <a href="#" class="btn btn-outline-dark btn-sm" title="Detail product">
                <i class="bx bx-search"></i>
              </a>
              <a href="<?php echo e(url('products/'.$product->id.'/edit')); ?>" class="btn btn-outline-dark btn-sm" title="Edit product">
                <i class="bx bx-pencil"></i>
              </a>
              <form action="<?php echo e(url('products/'.$product->id)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <?php if($product->status): ?>
                  <button type="submit" class="btn btn-outline-dark btn-sm" title="Inactivate product" onclick="return confirm('Are you sure you want to inactivate this product?')">
                    <i class="bx bx-trash"></i>
                  </button>
                <?php else: ?>
                  <button type="submit" class="btn btn-outline-dark btn-sm" title="Activate product" onclick="return confirm('Are you sure you want to activate this product?')">
                    <i class="bx bx-recycle"></i>
                  </button>
                <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp3\htdocs\supermarket-admin\resources\views/products/index.blade.php ENDPATH**/ ?>