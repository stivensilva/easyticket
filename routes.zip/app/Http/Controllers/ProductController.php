<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;

use Validator;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // $data = Product::where('status', 1)->get();
        $data = Product::all();
        return view('products.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::all();
        return view('products.new', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->all();

        $validation = Validator::make( $request->all(), [
            'name' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif',
            'category_id' => 'required|exists:categories,id',
            'description' => 'required'
        ]);
 
        if ($validation->fails()) {
            return redirect()->back()
                        ->withErrors($validation)
                        ->withInput();
        }

        $image = $request->file('image');
        $imageName = time().'.'.$image->getClientOriginalExtension();
        $image->move(public_path('images/products'), $imageName);

        Product::create([
            'name' => $request->input('name'),
            'description' => $request->input('description'),
            'image' => $imageName,
            'bestseller' => $request->input('bestseller'),
            'status' => $request->input('status'),
            'price' => $request->input('price'),
            'category_id' => $request->input('category_id'),
        ]);
        
        return redirect('products');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        echo "Metodo show - $id";
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $data = Product::find($id);
        $categories = Category::all();
        return view('products.edit', compact('data', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif',
            'category_id' => 'required|exists:categories,id',
            'description' => 'required',
        ]);

        $product = product::findOrFail($id);

        $product->name = $request->input('name');
        $product->price = $request->input('price');
        $product->status = $request->input('status');
        $product->bestseller = $request->input('bestseller');
        $product->category_id = $request->input('category_id');
        $product->description = $request->input('description');

        if ($request->hasFile('image')) {

            if ($product->image) {
                $filePath = public_path('images/products/' . $product->image);
                if (file_exists($filePath))
                    unlink($filePath);
            }
            
            $image = $request->file('image');
            $imageName = time().'.'.$image->getClientOriginalExtension();
            $image->move(public_path('images/products'), $imageName);
            $product->image = $imageName;
        }

        $product->save();

        return redirect('/products')->with('success', 'Product updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $product = Product::findOrFail($id);

        if ($product->status == 1) {
            $product->update(['status' => 0]);
            $message = 'Product inactivated successfully';
        } else {
            $product->update(['status' => 1]);
            $message = 'Product activated successfully';
        }

        return redirect('/products')->with('success', $message);
    }


}
