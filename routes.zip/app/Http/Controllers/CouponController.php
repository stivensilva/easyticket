<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Coupon;
use App\Models\Product;

use Validator;

class CouponController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Coupon::all();
        return view('coupons.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $products = Product::all();
        return view('coupons.new', compact('products'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->all();

        $validation = Validator::make( $request->all(), [
            'percentage' => 'required',
            'product_id' => 'required|exists:products,id',
            'startdate' => 'required|date',
            'enddate' => 'required|date',
            'status' => 'required|between:0,1',
        ]);
 
        if ($validation->fails()) {
            return redirect()->back()
                        ->withErrors($validation)
                        ->withInput();
        }

        Coupon::create([
            'product_id' => $request->input('product_id'),
            'percentage' => $request->input('percentage'),
            'startdate' => $request->input('startdate'),
            'enddate' => $request->input('enddate'),
            'status' => $request->input('status'),
        ]);
        
        return redirect('coupons');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        // echo "Metodo show - $id";
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $data = Coupon::find($id);
        $products = Product::all();
        return view('coupons.edit', compact('data', 'products'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $request->all();

        $validation = Validator::make( $request->all(), [
            'percentage' => 'required',
            'product_id' => 'required|exists:products,id',
            'startdate' => 'required|date',
            'enddate' => 'required|date',
            'status' => 'required|between:0,1',
        ]);
 
        if ($validation->fails()) {
            return redirect()->back()
                        ->withErrors($validation)
                        ->withInput();
        }

        Coupon::find($id)->update([
            'product_id' => $request->input('product_id'),
            'percentage' => $request->input('percentage'),
            'startdate' => $request->input('startdate'),
            'enddate' => $request->input('enddate'),
            'status' => $request->input('status'),
        ]);
        
        return redirect('/coupons')->with('success', 'Coupon updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $coupon = Coupon::findOrFail($id);

        if ($coupon->status == 1) {
            $coupon->update(['status' => 0]);
            $message = 'Coupon inactivated successfully';
        } else {
            $coupon->update(['status' => 1]);
            $message = 'Coupon activated successfully';
        }

        return redirect('/coupons')->with('success', $message);
    }


}
